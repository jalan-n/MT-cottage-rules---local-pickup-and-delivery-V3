/**
 * ============================================================================
 * HEADER LIVE SEARCH & MOBILE NAVIGATION (Vanilla ES6+)
 * ============================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Promotional Announcement Bar Dismissal
  const banner = document.getElementById('promo-announcement-bar');
  const dismissBtn = document.getElementById('dismiss-promo-btn');
  if (banner && dismissBtn) {
    if (sessionStorage.getItem('promo_banner_dismissed') === '1') {
      banner.style.display = 'none';
    }
    dismissBtn.addEventListener('click', () => {
      banner.style.display = 'none';
      sessionStorage.setItem('promo_banner_dismissed', '1');
    });
  }

  // 2. Mobile Nav Toggle
  const mobileToggle = document.getElementById('mobile-menu-toggle');
  const navBar = document.getElementById('site-nav-bar');
  if (mobileToggle && navBar) {
    mobileToggle.addEventListener('click', () => {
      const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
      mobileToggle.setAttribute('aria-expanded', String(!isExpanded));
      navBar.classList.toggle('nav-open');
    });
  }

  // 3. Live Keyword Search
  const searchInput = document.getElementById('header-search-input');
  const searchForm  = document.getElementById('header-search-form');
  const searchResults = document.getElementById('live-search-results');

  const catalog = [
    { name: "Wild Mountain Huckleberry Jam", slug: "huckleberry", desc: "Foraged high in the Cascade mountain slopes. Deep, vibrant woodland berry flavor with gentle natural sweetness.", img: "/assets/images/huckleberry.svg", price: "$9.00 - $17.00" },
    { name: "Rhubarb Huckleberry Jam", slug: "rhubarb-huckleberry", desc: "Tart valley-grown garden rhubarb folded into sweet wild huckleberries.", img: "/assets/images/rhubarb-huckleberry.svg", price: "$9.00 - $17.00" },
    { name: "Flathead Cherry Jam", slug: "flathead-cherry", desc: "Made with ripe sweet Flathead Lake cherries picked at the summer peak.", img: "/assets/images/flathead-cherry.svg", price: "$9.00 - $17.00" },
    { name: "Pacific Wild Raspberry Jam", slug: "raspberry", desc: "Pure sun-ripened red raspberries with natural berry aroma.", img: "/assets/images/raspberry.svg", price: "$9.00 - $17.00" },
    { name: "Strawberry Vanilla Bean Jam", slug: "strawberry-vanilla-bean", desc: "Ripe valley strawberries gently simmered with whole Madagascar bourbon vanilla pods.", img: "/assets/images/strawberry-vanilla-bean.svg", price: "$9.00 - $17.00" },
    { name: "Pineapple Toasted Coconut Jam", slug: "pineapple-toasted-coconut", desc: "Crushed sweet golden pineapple simmered with toasted organic coconut flakes.", img: "/assets/images/pineapple-toasted-coconut.svg", price: "$9.00 - $17.00" }
  ];

  if (searchInput && searchResults) {
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.trim().toLowerCase();
      if (!q) {
        searchResults.style.display = 'none';
        searchResults.innerHTML = '';
        return;
      }

      const matches = catalog.filter(p => 
        p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q)
      );

      if (matches.length === 0) {
        searchResults.innerHTML = `<div class="search-no-results">No jams matching "<strong>${escapeHtml(q)}</strong>".</div>`;
        searchResults.style.display = 'block';
      } else {
        searchResults.innerHTML = matches.map(p => `
          <a href="/product-${p.slug}.html" class="search-result-item">
            <img src="${p.img}" alt="${escapeHtml(p.name)}" class="search-thumb" width="36" height="36" loading="lazy">
            <div class="search-info">
              <span class="search-title">${escapeHtml(p.name)}</span>
              <span class="search-price">${p.price}</span>
            </div>
          </a>
        `).join('');
        searchResults.style.display = 'block';
      }
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
        searchResults.style.display = 'none';
      }
    });
  }

  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const q = searchInput ? searchInput.value.trim() : '';
      if (q) {
        window.location.href = `/shop.html?search=${encodeURIComponent(q)}`;
      }
    });
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
  }
});
