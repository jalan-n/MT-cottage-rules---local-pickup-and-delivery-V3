<?php
declare(strict_types=1);
/**
 * Shared SSG Footer Template
 * Semantic footer with links, brand details, slide-over cart drawer, and scripts.
 */
$brandName     = $settings['brand_name'] ?? "Shelly's Jellys LLC";
$pickupAddress = $settings['pickup_address'] ?? '458 Orchard Vista Way, Kalispell, MT 59901';
$currentYear   = date('Y');
?>
  </main>

  <!-- Slide-over Cart Drawer -->
  <div id="cart-drawer-overlay" class="drawer-overlay" aria-hidden="true"></div>
  <aside id="cart-drawer" class="cart-drawer" aria-label="Shopping Cart Drawer" aria-hidden="true">
    <div class="drawer-header">
      <h2 class="drawer-title">&#128722; Your Basket</h2>
      <button type="button" id="cart-drawer-close" class="drawer-close-btn" aria-label="Close basket">&times;</button>
    </div>

    <!-- Drawer Line Items List -->
    <div id="drawer-items-list" class="drawer-body">
      <!-- Injected dynamically by cart.js -->
      <p class="empty-state">Your basket is currently empty.</p>
    </div>

    <!-- Drawer Footer & Actions -->
    <div class="drawer-footer">
      <div class="drawer-subtotal-row">
        <span>Items Subtotal:</span>
        <strong id="drawer-subtotal-val">$0.00</strong>
      </div>
      <p class="drawer-delivery-note">Taxes and local delivery fee calculated at checkout.</p>
      <div class="drawer-buttons-row">
        <a href="/cart.html" class="btn-secondary drawer-cart-page-btn">View Full Basket</a>
        <a href="/checkout.html" class="btn-emerald drawer-checkout-btn">Checkout &rarr;</a>
      </div>
    </div>
  </aside>

  <!-- Site Footer -->
  <footer class="site-footer">
    <div class="footer-inner">
      <div class="footer-col brand-col">
        <img src="/assets/images/shellys-jellys-logo.svg" alt="Shelly's Jellys LLC" class="footer-logo" width="160" height="52" loading="lazy">
        <p class="footer-tagline">Homemade jam. More fruit. Less sugar. No preservatives.</p>
        <p class="footer-subtext">Handcrafted in small batches in Kalispell, Montana. Local pickup and delivery across Flathead County.</p>
      </div>

      <div class="footer-col links-col">
        <h3 class="footer-heading">Quick Links</h3>
        <ul class="footer-links">
          <li><a href="/shop.html">Shop all flavors</a></li>
          <li><a href="/packs.html">Build a Pack</a></li>
          <li><a href="/gift-box.html">Build a Gift Box</a></li>
          <li><a href="/custom-orders.html">Special Orders</a></li>
          <li><a href="/contact.html">Contact Us</a></li>
          <li><a href="/cart.html">View Basket</a></li>
        </ul>
      </div>

      <div class="footer-col contact-col">
        <h3 class="footer-heading">Kitchen & Farmstand</h3>
        <address class="footer-address">
          <?= htmlspecialchars($pickupAddress) ?><br>
          Kalispell, MT 59901<br>
          Phone: <a href="tel:4065550192">(406) 555-0192</a><br>
          Email: <a href="mailto:mtshellysjellys@gmail.com">mtshellysjellys@gmail.com</a>
        </address>
        <div class="footer-vcard-wrap">
          <a href="/ShellysJellyscontact.vcf" download="ShellysJellyscontact.vcf" class="vcard-link">
            &#128100; Download vCard Contact File
          </a>
        </div>
      </div>
    </div>

    <div class="footer-bottom-bar text-center">
      <p>&copy; <?= $currentYear ?> <?= htmlspecialchars($brandName) ?>. All rights reserved. Artisan Gourmet Jams &amp; Preserves.</p>
    </div>
  </footer>

  <!-- Vanilla Scripts -->
  <script src="/js/search.js"></script>
  <script src="/js/cart.js"></script>
  <script src="/js/fulfillment.js"></script>
  <?php if (str_contains($canonical ?? '', 'packs')): ?>
    <script src="/js/pack-builder.js"></script>
  <?php elseif (str_contains($canonical ?? '', 'gift-box')): ?>
    <script src="/js/gift-box-builder.js"></script>
  <?php elseif (str_contains($canonical ?? '', 'checkout')): ?>
    <script src="/js/checkout.js"></script>
  <?php endif; ?>
</body>
</html>
